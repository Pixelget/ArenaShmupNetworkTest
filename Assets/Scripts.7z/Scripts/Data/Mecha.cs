﻿using UnityEngine;
using System.Collections;

public enum FrameType { Assassin, Defender, Specialist }
public enum AbilityType { MissileBarrage, Funnels, AreaMines, Shielding }
// MissileBarrage - Fires a round of Homing Missiles
// Funnels - robots with AI that shoot at players and dart around
// Area Mines - Think Shmup, Circle mines that shoot out in all directions and rest in place until a hostile gets too close
// Shielding - Negates the first amount of damage taken
public class Mecha {
    /*bool AIControlled = false;

    string name = "Wraith";
    GameObject MechaPrefab;

    AbilityType abilityType = AbilityType.MissileBarrage;
    FrameType Type = FrameType.Specialist;
    
    int TotalHealth = 100;
    float speed = 1f;*/
}
